O resultado da simulação com figuras dos gráficos encontra-se em Simulacao.pdf

Para rodar o script de python:
- Instalar Python 3
- Instalar as bibliotecas Numpy, Scipy e Matplotlib

Então ao rodar pela linha de comando, para obter ajuda:
$ python Simulacao.py --help

Para rodar a simulação com entradas default:
$ python Simulacao.py